#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x = 3 +++ 5 +++ 4;
    printf("Hello world!\n");
    return 0;
}
